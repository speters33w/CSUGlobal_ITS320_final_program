# Output integer and float product and modulus of two numbers.
number1 = int(input('Enter a number: '))
number2 = int(input('Enter a number: '))
print(number1, '//', number2, 'is', str(number1 // number2) + '.')
print(number1, '/', number2, 'is', str(number1 / number2) + '.')
print(number1, '%', number2, 'is', str(number1 % number2) + '.')
